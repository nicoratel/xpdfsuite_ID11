"""Onglet « Extract xPDF » : extraction des PDF G(r) pour chaque frame/groupe de frames."""

from __future__ import annotations

import json
import numpy as np
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

from xpdfsuite_ID11 import extract_xpdf, ID11Data, XRDProcessor
from xpdfsuite_ID11.app_utilities import open_fig_in_browser
from xpdfsuite_ID11.utilities_process import (
    compute_reaction_time_stop_flow,
    convert_position_to_time,
    extract_number_of_images,
    match_frames_by_motor_positions,
)

from .configure import ExperimentConfig


def render(cfg: ExperimentConfig) -> None:
    # --- Paramètres fournis par l'onglet « Configure Experiment » ---
    sample_file = cfg.sample_file
    ref_file = cfg.ref_file
    poni_file = cfg.poni_file
    mask_path = cfg.mask_path
    polarization = cfg.polarization
    entry_sample = cfg.entry_sample
    entry_ref = cfg.entry_ref
    frame_binning = cfg.frame_binning
    frame_step = cfg.frame_step
    nb_repeats = cfg.nb_repeats
    option = cfg.option
    position_tol = cfg.position_tol
    position0 = cfg.position0
    x_coude = cfg.x_coude
    z_retour = cfg.z_retour
    debit = cfg.debit
    section = cfg.section
    section_tri = cfg.section_tri
    long_tri = cfg.long_tri

    st.markdown("## 🧮 Extract PDF")
    # ========== DEFAULT VALUES ==========
    _default_bgscale = st.session_state.get("bgscale", 1.0)
    _default_qmin = 0.5
    _default_qmax = 24.5
    _default_qmaxinst = 24.5
    _default_rpoly = 0.9
    _default_lorch = True
    _default_composition = "Au"
    
    # ========== INPUT PARAMETERS SECTION ==========
    st.markdown("## 📋 Input Parameters")
    
    composition = st.text_input("Chemical composition", value=_default_composition, placeholder="e.g., Au, NaCl, Au3Cu")
    
    st.markdown("## ⚙️ Extraction Parameters")
    
    col_out1, col_out2, col_out3, col_out4 = st.columns(4)
    
    with col_out1:
        st.markdown("**Gamme de Rsouhaitée**")
        rmin = st.number_input("rmin (Å)", value=0.0, step=0.1)
        rmax = st.number_input("rmax (Å)", value=50.0, step=0.1)
        rstep = st.number_input("rstep (Å)", value=0.01, step=0.001)
    
    with col_out2:
        st.markdown("**Gamme de Q utilisée pour l'extraction**")
        
        qmin = st.number_input("qmin (Å⁻¹)", value=_default_qmin, step=0.01)
        qmax = st.number_input("qmax (Å⁻¹)", value=_default_qmax, step=0.01)
        

    with col_out3:
        st.markdown("**Paramètres pour la soustraction polynomiale**")
        qmaxinst = st.number_input("qmaxinst (Å⁻¹)", value=_default_qmaxinst, step=0.01,help="Maximum Q value for the instrument correction. If None, the maximum Q value will be used.")
        rpoly = st.number_input("rpoly", value=_default_rpoly, step=0.01, help="Polynomial correction parameter. It should be kept < 1.5.")
        lorch = st.checkbox("Lorch", value=_default_lorch, help="Apply Lorch modification to the Fourier transform. It is recommended to keep this option checked.")

    with col_out4:
        st.markdown("**Background Scaling**")
        bgscale = st.number_input("bgscale", value=_default_bgscale, step=0.01, help="Scaling factor for the background subtraction. It should be kept < 1.5.")


    if st.button("Calcuer PDF", type="primary"):
        
        if sample_file is None:
            st.error("Please upload sample file ")
        else:
            # Call the appropriate function based on the selected option

            ############################################### LOST FLOW ########################################################
            if option == "lost_flow":
                if entry_sample is None:
                    eiger = ID11Data(sample_file)
                    entry_sample = eiger.entries[0]
                else:
                    eiger = ID11Data(sample_file)
                
                nb_images = extract_number_of_images(sample_file, entry_sample,poni_file)
                #nb_images_ref = nb_images # here we assume the reference file has the same number of images as the sample file. If not, you can modify this to extract the number of images from the reference file as well.
                pdf_files = []
                #if nb_images != nb_images_ref:
                #    raise ValueError("The number of images in the sample and reference files do not match.")

                # Appariement des frames de l'échantillon avec celles de la référence par position
                # moteur (difftz/samty/samtz), à la place de l'hypothèse "même indice de frame".
                ref_frame_map = {}
                if ref_file is not None:
                    matches, unmatched = match_frames_by_motor_positions(
                        sample_file, ref_file, tol=position_tol,
                        entry_sample=entry_sample, entry_ref=entry_ref)
                    ref_frame_map = {m['sample_frame']: m['ref_frame'] for m in matches}
                    if unmatched:
                        missing = [u['sample_frame'] for u in unmatched]
                        st.warning(f"Aucune image de référence trouvée à {position_tol*1000:.0f} µm près pour les "
                                   f"frames échantillon {missing} ; indice identique utilisé en secours pour celles-ci.")
            
                if frame_step is None:
                    # Comportement actuel : groupes consécutifs uniquement
                    nb_bins = nb_images // frame_binning
                    if nb_bins == 0:
                        raise ValueError(f"frame_binning={frame_binning} is larger than the number of images ({nb_images}).")
                    if nb_images % frame_binning != 0:
                        print(f"Warning: {nb_images} images is not a multiple of frame_binning={frame_binning}; "
                            f"the last {nb_images % frame_binning} image(s) will be discarded.")
                    nb_repeats_eff = 1
                    series_len = nb_images
                else:
                    if frame_step < frame_binning:
                        raise ValueError(f"frame_step={frame_step} must be >= frame_binning={frame_binning}.")
                    series_len = frame_step
                    max_repeats = nb_images // frame_step
                    nb_repeats_eff = max_repeats if nb_repeats is None else nb_repeats
                    if nb_repeats_eff < 1 or nb_repeats_eff > max_repeats:
                        raise ValueError(f"nb_repeats={nb_repeats} invalid: {nb_images} images with "
                                        f"frame_step={frame_step} allow at most {max_repeats} repeats.")
                    if frame_step % frame_binning != 0:
                        print(f"Warning: frame_step={frame_step} is not a multiple of frame_binning={frame_binning}; "
                            f"the last {frame_step % frame_binning} frame(s) of each series will be discarded.")
                    if nb_images % frame_step != 0 and nb_repeats is None:
                        print(f"Warning: {nb_images % frame_step} trailing image(s) do not form a complete series and will be discarded.")
                    nb_bins = frame_step // frame_binning

                st.session_state["nb_bins"] = nb_bins
                res = {}
                sample_processor = XRDProcessor(sample_file, frame=0, poni_file=poni_file,
                                                                    mask=mask_path, polarization_factor=polarization, entry=entry_sample)
                st.session_state["samplename"] = sample_processor.samplename
                fig = go.Figure(
                    layout=go.Layout(
                        title=f"Lost flow - sample: {sample_processor.samplename}",  # Titre général
                        xaxis_title="r (Å)",
                        yaxis_title="G(r)"))
                palette = px.colors.sample_colorscale(
    "Bluered", [i / max(nb_bins - 1, 1) for i in range(nb_bins)]
)
                
                n=0
                progress_bar_gr_lostflow = st.progress(0, text="Calcul du PDF en cours...")
                for bin_idx in range(nb_bins):
                    couleur_courbe = palette[bin_idx % len(palette)]
                    base = bin_idx * frame_binning
                    step = frame_step if frame_step is not None else 0
                    frame_group = [
                        base + k + r * step
                        for r in range(nb_repeats_eff)
                        for k in range(frame_binning)
                    ]
                    frame_arg = frame_group[0] if len(frame_group) == 1 else frame_group
                    res[str(frame_group)] = {}
                    print(f"Processing frame group: {frame_group}")

                    sample_processor = XRDProcessor(sample_file, frame=frame_arg, poni_file=poni_file,
                                                    mask=mask_path, polarization_factor=polarization, entry=entry_sample)
                    if ref_file is not None:
                        frame_group_ref = [ref_frame_map.get(f, f) for f in frame_group]
                        frame_arg_ref = frame_group_ref[0] if len(frame_group_ref) == 1 else frame_group_ref
                        ref_processor = XRDProcessor(ref_file, frame=frame_arg_ref, poni_file=poni_file, mask=mask_path, polarization_factor=polarization, entry=entry_ref)
                    else:
                        ref_processor = None
            
                    
                    if len(frame_group) == 1:
                        frame_str = str(frame_group[0])
                    else:
                        frame_str = f"{frame_group[0]}-{frame_group[-1]}"
                    #outputfile = f'{os.path.dirname(sample_file)}/{os.path.basename(sample_file).split(".")[0]}_frames={frame_str}.gr'


                    # Retrieve motor positions for the current frame group and compute reaction time based on the motor positions
                    
                    scanned = sample_processor.scanned_motors

                    # Position de chaque moteur (on suppose la position constante sur les frames binnées → premier élément)
                    position = {
                        motor: value[bin_idx] if frame_binning == 1 else value[frame_group][0]
                        for motor, value in scanned.items()
                    }

                    # Vecteur [y, z]
                    position_tuple = np.array([
                        next((v for m, v in position.items() if 'y' in m), 0.0),
                        next((v for m, v in position.items() if 'z' in m), 0.0),
                    ])
                    

                    print(f"position tuple for frame group {frame_group}: {position_tuple}")
                    time = convert_position_to_time(position_tuple,position0=position0, x_coude=x_coude, z_retour=z_retour, debit=debit,
                   section=section, long_tri=long_tri, section_tri=section_tri, tol=0.1)

                    # Extract PDF from sample and reference data                                     
                    r, G = extract_xpdf(sample_processor,
                                        ref_processor=ref_processor,
                                        composition=composition,
                                        rmin=rmin,
                                        rmax=rmax,
                                        rstep=rstep,
                                        #outputfile=outputfile,
                                        interactive=False,
                                        plot=False,
                                        bgscale=bgscale,
                                        qmin=qmin,
                                        qmax=qmax,
                                        qmaxinst=qmaxinst,
                                        rpoly=rpoly)
                    # ajout plotly pour visualiser G(r) en fonction du temps
                    res[str(frame_group)]['r'] = r
                    res[str(frame_group)]['G'] = G
                    res[str(frame_group)]['time'] = time
                    
                    fig.add_trace(go.Scatter(x=r, 
                        y=G / G.max()+n, 
                        mode='lines', 
                        name=f"time={time:.2f}s",
                        line=dict( color=couleur_courbe,width=2))) # <--- On force l'application de la couleur ici
                    n+=0.02
                    progress_bar_gr_lostflow.progress((bin_idx + 1) / nb_bins, text=f"Calcul du PDF {bin_idx + 1}/{nb_bins}")
                                    
                                    
                progress_bar_gr_lostflow.empty()
                st.session_state["fig_gr"] = fig
                st.session_state["res"] = res   # <-- à ajouter



#################################################################" STOP FLOW ########################################"




            elif option == "stop_flow":
                if entry_sample is None:
                    
                    eiger = ID11Data(sample_file)
                    entry_sample = eiger.entries[0]
                    
                
                nb_images = extract_number_of_images(sample_file, entry_sample,poni_file)
                #nb_images_ref = nb_images # here we assume the reference file has the same number of images as the sample file. If not, you can modify this to extract the number of images from the reference file as well.
                pdf_files = []
                #if nb_images != nb_images_ref:
                #    raise ValueError("The number of images in the sample and reference files do not match.")

                # Appariement des frames de l'échantillon avec celles de la référence par position
                # moteur (difftz/samty/samtz), à la place de l'hypothèse "même indice de frame".
                ref_frame_map = {}
                if ref_file is not None:
                    matches, unmatched = match_frames_by_motor_positions(
                        sample_file, ref_file, tol=position_tol,
                        entry_sample=entry_sample, entry_ref=entry_ref)
                    ref_frame_map = {m['sample_frame']: m['ref_frame'] for m in matches}
                    if unmatched:
                        missing = [u['sample_frame'] for u in unmatched]
                        st.warning(f"Aucune image de référence trouvée à {position_tol*1000:.0f} µm près pour les "
                                   f"frames échantillon {missing} ; indice identique utilisé en secours pour celles-ci.")
            
                
                nb_bins = nb_images
                st.session_state["nb_bins"] = nb_bins
                res = {}
                sample_processor = XRDProcessor(sample_file, frame=0, poni_file=poni_file,
                                                                    mask=mask_path, polarization_factor=polarization, entry=entry_sample)
                fig = go.Figure(
                    layout=go.Layout(
                        title=f"Stop flow - sample {sample_processor.samplename}",  # Titre général
                        xaxis_title="r (Å)",
                        yaxis_title="G(r)"))
                palette = px.colors.sample_colorscale("Bluered", [i / max(nb_bins - 1, 1) for i in range(nb_images)]
)
                n=0
                progress_bar_gr_stopflow = st.progress(0, text="Calcul du PDF en cours...")
                for bin_idx in range(nb_images):
                    couleur_courbe = palette[bin_idx % len(palette)]
                    res[str(bin_idx)] = {}
                    print(f"Processing frame group: {bin_idx}")
                    frame_arg = bin_idx
                    sample_processor = XRDProcessor(sample_file, frame=frame_arg, poni_file=poni_file,
                                                    mask=mask_path, polarization_factor=polarization, entry=entry_sample)
                    
                    if ref_file is not None:
                        frame_arg_ref = ref_frame_map.get(bin_idx, bin_idx)
                        ref_processor = XRDProcessor(ref_file, frame=frame_arg_ref, poni_file=poni_file, mask=mask_path, polarization_factor=polarization, entry=entry_ref)
                    else:
                        ref_processor = None
                    frame_group = [bin_idx] 
                    # Extract PDF from sample and reference data
                    if len(frame_group) == 1:
                        frame_str = str(frame_group[0])
                    else:
                        frame_str = f"{frame_group[0]}-{frame_group[-1]}"
                    #outputfile = f'{os.path.dirname(sample_file)}/{os.path.basename(sample_file).split(".")[0]}_frames={frame_str}.gr'
                    timedict={}
            
                    reaction_time =compute_reaction_time_stop_flow(sample_processor)
                    for i, frame in enumerate(frame_group):
                        timedict[str(frame)] = reaction_time[i]
            
                    res[str(bin_idx)]['reaction_time'] = timedict
                    
                    r, G = extract_xpdf(sample_processor,
                                        ref_processor=ref_processor,
                                        composition=composition,
                                        rmin=rmin,
                                        rmax=rmax,
                                        rstep=rstep,
                                        #outputfile=outputfile,
                                        interactive=False,
                                        plot=False,
                                        bgscale=bgscale,
                                        qmin=qmin,
                                        qmax=qmax,
                                        qmaxinst=qmaxinst,
                                        rpoly=rpoly)
                    res[str(bin_idx)]['r'] = r
                    res[str(bin_idx)]['G'] = G
                    res[str(bin_idx)]['time'] = reaction_time[bin_idx]

                    print("PDF computed for reaction time: ", reaction_time[bin_idx])

                    fig.add_trace(go.Scatter(x=r, 
                                             y=G / G.max()+n, 
                                             mode='lines', 
                                             name=f"time={reaction_time[bin_idx]:.2f}s",
                                             line=dict( color=couleur_courbe,width=2)))
                    n+=0.02
                    progress_bar_gr_stopflow.progress((bin_idx + 1) / nb_images, text=f"Calcul du PDF {bin_idx + 1}/{nb_images}")
                
                progress_bar_gr_stopflow.empty()
                st.session_state["fig_gr"] = fig
                st.session_state["res"] = res   # <-- à ajouter

    fig_gr_display = st.session_state.get("fig_gr")
    if fig_gr_display is not None:
        st.plotly_chart(fig_gr_display, use_container_width=True)
        if st.button("🪟 Ouvrir dans une fenêtre séparée", key="open_window_gr"):
            
            html = fig_gr_display.to_html(
                full_html=True,
                include_plotlyjs=True, 
                config={"responsive": True},
            )
            # Injection du titre de l'onglet
            fig_title = f"G(r):{st.session_state.get('samplename', 'Unknown')} {st.session_state.get('iq_raw_data')['option']} "
            open_fig_in_browser(fig_gr_display, tab_title=fig_title, filename=f"PDFs_{st.session_state.get('samplename', 'Unknown')}.html")

    json_res = json.dumps(st.session_state.get("res"), indent=4, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o),)
    st.download_button(
        label="Download PDF data as JSON",
        data=json_res,
            file_name=f"pdf_data_sample_{st.session_state.get('samplename')}.json",
            mime="application/json",
        key="download_pdf_data"
    )
